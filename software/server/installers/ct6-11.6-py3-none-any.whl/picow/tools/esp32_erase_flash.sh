#!/bin/sh
python3 -m esptool --chip esp32 erase_flash