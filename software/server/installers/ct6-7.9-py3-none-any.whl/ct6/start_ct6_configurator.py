import ct6.ct6_configurator

def dummy():
    pass

ct6.ct6_configurator.main()