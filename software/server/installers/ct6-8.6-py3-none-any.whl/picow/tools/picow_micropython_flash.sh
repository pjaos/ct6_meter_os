#!/bin/sh
# This script requires one argument that contains the RPI-RP2
# folder when the RPi PicoW is powered up with it's button 
# being held down.
cp picow_flash_images/firmware.uf2 $1